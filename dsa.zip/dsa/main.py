def leftrotate(s, d):
    tmp = s[d : ] + s[0 : d]
    return tmp
   
def rightrotate(s, d):
   
   return leftrotate(s, len(s) - d)
 
     
str1 =  [1, 3, 2, 7, 4, 6, 8]
print(leftrotate(str1, 3))
  
str2 =  [1, 3, 2, 7, 4, 6, 8]
print(rightrotate(str2, 3))