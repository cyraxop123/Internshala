def leftrotate(s, d):
    tmp = s[d : ] + s[0 : d]
    return tmp
   
def rightrotate(s, d):
   
   return leftrotate(s, len(s) - d)
 
str1 =  [1, 3, 2, 7, 4, 6, 8]

try:
    p = input("Enter possition: ")
    if(int(p) >= len(str1)):
        print("Possition should be lesser than length of list")
        exit()
    if(int(p) <= 0):
        print("Possition should be bigger than 0")
        exit()
    print("")
    d = input("Enter Direction: ")

    if int(d) == 0:
        print(leftrotate(str1, int(p)))

    elif int(d) == 1:
        print(rightrotate(str1, int(p)))

    else:
        print("invalid choice")
except Exception as e:
    print(e)